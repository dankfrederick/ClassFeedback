﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ClassFeedback.Modeles
{
    public class RoomOwner : User
    {

    }
}
